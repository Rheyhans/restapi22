__path = process.cwd()

var { performance } = require('perf_hooks');
var fetch = require('node-fetch');
var express = require('express');
var router = express.Router();
var db = require(__path + '/database/db');
//var dbo = db.get('apikey'); 

router.get('/', (req, res) => {
    res.sendFile(__path + '/views/home.html')
})

router.get('/login', (req, res) => {
    res.sendFile(__path + '/views/login.html')
}) 

router.get('/register', (req, res) => {
    res.sendFile(__path + '/views/register.html')
})

router.get('/api', (req, res) => {
    res.sendFile(__path + '/views/index.html')
})

router.get('/api/game', (req, res) => {
    res.sendFile(__path + '/views/game.html')
})

router.get('/api/tutorial', (req, res) => {
    res.sendFile(__path + '/views/tutorial.html')
})

/*router.post('/login', (req, res) => {
    dbo.collection('api').findOne({
        email: req.body.email,
        password: req.body.password
    }, (err, data) => {
        if (err) {
            return res.status(500).json({
                code: 500,
                message: err.message
            })
        }
        if (!data) {

            return res.status(200).json({

                code: 1,
                message: 'email or password error'
            })
        } else {
            req.session.user = data
            res.status(200).json({
                code: 0,
                message: 'login success'
            })
        }
    })
})


router.post("/sign_up",(req,res)=>{
    var name = req.body.name;
    var email = req.body.email;
    var phno = req.body.phno;
    var password = req.body.password;

    var data = {
        "name": name,
        "email" : email,
        "phno": phno,
        "password" : password
    }

    dbo.collection('apikey').insertOne(data,(err,collection)=>{
        if(err){
            throw err;
        }
console.log("Record Inserted Successfully");
    });

    return res.redirect('/views/signup_success.html')

})

router.get('/logout', (req, res) => {
    req.session.user = null

    res.redirect('/login')
})*/

router.get('/api/status', async(req, res) => {  

var date = new Date
var jam = date.getHours()
var menit = date.getMinutes()
var detik = date.getSeconds()
var old = performance.now()
var neww = performance.now()
var ram = `${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB`
var cpu = require('os').cpus()
var json = await (await fetch('https://api.ipify.org/?format=json')).json()
var port = process.env.PORT || 3000 
    status = {
        status: 'online',
        memory: ram,
        cpu: cpu[0].model,
        port: port,
        time: `${jam} : ${menit} : ${detik}`,
        uptime: muptime(process.uptime()),
        speed: `${neww - old}ms`,
        info:{       
            owner: 'Rhey',            
            apikey: 'Chat Owner: https://wa.me/6285895001126'
        }
    }
    res.json(status)
})

module.exports = router

function muptime(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);

  return pad(hours) + ' : ' + pad(minutes) + ' : ' + pad(seconds)
}
